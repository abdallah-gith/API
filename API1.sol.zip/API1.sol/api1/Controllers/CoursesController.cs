﻿using Microsoft.AspNetCore.Mvc;
using CourseApi.Data;
using CourseApi.Models;
using System.Linq;

namespace CourseApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CoursesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CoursesController(AppDbContext context)
        {
            _context = context;
        }

        // GET api/courses
        [HttpGet]
        public IActionResult Get()
        {
            var list = _context.Courses.ToList();
            if (list.Count == 0)
                return NotFound();
            return Ok(list);
        }

        // GET api/courses/{id}
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var course = _context.Courses.Find(id);
            if (course == null)
                return NotFound();
            return Ok(course);
        }

        // GET api/courses/byname/{name}
        [HttpGet("byname/{name}")]
        public IActionResult GetByName(string name)
        {
            var course = _context.Courses
                .FirstOrDefault(c => c.Name.ToLower() == name.ToLower());
            if (course == null)
                return NotFound();
            return Ok(course);
        }

        // POST api/courses
        [HttpPost]
        public IActionResult Post([FromBody] Course course)
        {
            if (course == null)
                return BadRequest();

            _context.Courses.Add(course);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { id = course.Id }, course);
        }

        // PUT api/courses/{id}
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Course course)
        {
            if (course == null || id != course.Id)
                return BadRequest();

            var existing = _context.Courses.Find(id);
            if (existing == null)
                return NotFound();

            existing.Name = course.Name;
            existing.Description = course.Description;
            existing.Credits = course.Credits;
            _context.SaveChanges();

            return NoContent();
        }

        // DELETE api/courses/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var existing = _context.Courses.Find(id);
            if (existing == null)
                return NotFound();

            _context.Courses.Remove(existing);
            _context.SaveChanges();

            return Ok(_context.Courses.ToList());
        }
    }
}
